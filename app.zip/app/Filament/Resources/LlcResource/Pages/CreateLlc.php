<?php

namespace App\Filament\Resources\LlcResource\Pages;

use App\Filament\Resources\LlcResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLlc extends CreateRecord
{
    protected static string $resource = LlcResource::class;
}
